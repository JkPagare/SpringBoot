import React from "react";

const DeleteProductComponent = () => {
    return (
        <div>
            <button type="button" class="btn btn-danger">Delete Product</button>  
        </div>
    )
}

export default DeleteProductComponent;
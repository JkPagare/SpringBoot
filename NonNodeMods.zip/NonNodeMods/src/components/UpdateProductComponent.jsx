import React from "react";

const UpdateProductComponent = () => {
    return (
        <div className="update-prod">
          <button type="button" class="btn btn-primary">Update Product</button>  
        </div>
    )
}

export default UpdateProductComponent;
import React from "react"

export const FooterComponent = () =>{
    return(
        <div>
        <footer className="fixed-bottom">
        <nav className="navbar navbar-dark bg-dark justify-content-center">
            <span className="navbar-brand h1 text-center">My First App</span>
        </nav>
        </footer>
        </div>
    )
}